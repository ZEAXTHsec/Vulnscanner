'use client'

// components/scanner/TopIssues.tsx
// Shows the top 3 highest-impact failures with:
//   - "Fix this → score goes from X to Y" preview
//   - "Ask AI" copy button per issue
// Placed above the results table so the user knows what to do first.

import { useState } from 'react'
import { ScanResult, ScanSummary } from '@/lib/types'

interface Props {
  results: ScanResult[]
  summary: ScanSummary
}

const SEVERITY_WEIGHT: Record<string, number> = {
  high:   3,
  medium: 2,
  low:    1,
  info:   0,
}

// Must match runner.ts penalty weights exactly
const PENALTY_WEIGHT: Record<string, number> = {
  high:   12,
  medium: 6,
  low:    2,
  info:   0,
}

const SEVERITY_COLOR: Record<string, string> = {
  high:   '#ef4444',
  medium: '#f97316',
  low:    '#eab308',
  info:   '#6b7280',
}

const SEVERITY_BG: Record<string, string> = {
  high:   '#fef2f2',
  medium: '#fff7ed',
  low:    '#fefce8',
  info:   '#f9fafb',
}

export default function TopIssues({ results, summary }: Props) {
  const [copied, setCopied] = useState<string | null>(null)
  const [dismissed, setDismissed] = useState(false)

  if (dismissed) return null

  const failures = results.filter((r) => r.status === 'fail')

  // Nothing actionable
  if (failures.length === 0) {
    return (
      <div style={{
        background: '#f0fdf4',
        border: '1px solid #86efac',
        borderRadius: '12px',
        padding: '16px 20px',
        marginBottom: '1.5rem',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        color: '#15803d',
        fontWeight: 600,
        fontSize: '0.95rem',
      }}>
        ✅ No critical issues found — this site is well-configured.
      </div>
    )
  }

  // Sort by severity weight, then by penalty (most impactful first)
  const top = [...failures]
    .sort((a, b) => {
      const sw = (SEVERITY_WEIGHT[b.severity] ?? 0) - (SEVERITY_WEIGHT[a.severity] ?? 0)
      if (sw !== 0) return sw
      return (PENALTY_WEIGHT[b.severity] ?? 0) - (PENALTY_WEIGHT[a.severity] ?? 0)
    })
    .slice(0, 3)

  const handleCopy = (checkId: string, prompt: string) => {
    navigator.clipboard.writeText(prompt).then(() => {
      setCopied(checkId)
      setTimeout(() => setCopied(null), 2000)
    })
  }

  return (
    <div style={{
      background: '#fffbeb',
      border: '1px solid #fde68a',
      borderRadius: '12px',
      padding: '16px 20px',
      marginBottom: '1.5rem',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
        <div>
          <span style={{ fontWeight: 700, fontSize: '0.95rem', color: '#92400e' }}>
            ⚡ Fix these first
          </span>
          <span style={{ marginLeft: '8px', fontSize: '0.8rem', color: '#a16207' }}>
            — highest impact on your score
          </span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: '#a16207', fontSize: '1rem', lineHeight: 1, padding: '2px 6px',
          }}
          title="Dismiss"
        >
          ×
        </button>
      </div>

      {/* Issue list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {top.map((issue, i) => {
          const gain = PENALTY_WEIGHT[issue.severity] ?? 0
          const newScore = Math.min(100, summary.score + gain)
          const color = SEVERITY_COLOR[issue.severity] ?? '#6b7280'
          const bg = SEVERITY_BG[issue.severity] ?? '#f9fafb'

          return (
            <div
              key={issue.checkId}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                background: 'white',
                borderRadius: '8px',
                padding: '10px 14px',
                border: '1px solid #e5e7eb',
              }}
            >
              {/* Rank */}
              <span style={{
                fontWeight: 700,
                color: '#9ca3af',
                fontSize: '0.82rem',
                minWidth: '16px',
              }}>
                {i + 1}.
              </span>

              {/* Severity badge */}
              <span style={{
                background: bg,
                color,
                padding: '2px 8px',
                borderRadius: '999px',
                fontSize: '0.7rem',
                fontWeight: 700,
                textTransform: 'uppercase' as const,
                letterSpacing: '0.05em',
                whiteSpace: 'nowrap' as const,
              }}>
                {issue.severity}
              </span>

              {/* Name */}
              <span style={{ flex: 1, fontWeight: 600, fontSize: '0.88rem', color: '#111' }}>
                {issue.name}
              </span>

              {/* Score delta */}
              {gain > 0 && (
                <span style={{
                  fontSize: '0.75rem',
                  color: '#16a34a',
                  fontWeight: 600,
                  whiteSpace: 'nowrap' as const,
                  background: '#f0fdf4',
                  padding: '2px 8px',
                  borderRadius: '6px',
                  border: '1px solid #bbf7d0',
                }}>
                  {summary.score} → {newScore} ↑{gain}pts
                </span>
              )}

              {/* Ask AI button */}
              {issue.fixPrompt ? (
                <button
                  onClick={() => handleCopy(issue.checkId, issue.fixPrompt!)}
                  style={{
                    padding: '5px 12px',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    border: '1px solid',
                    borderColor: copied === issue.checkId ? '#16a34a' : '#d1d5db',
                    borderRadius: '6px',
                    background: copied === issue.checkId ? '#f0fdf4' : 'white',
                    color: copied === issue.checkId ? '#16a34a' : '#374151',
                    cursor: 'pointer',
                    whiteSpace: 'nowrap' as const,
                    transition: 'all 0.15s',
                  }}
                >
                  {copied === issue.checkId ? '✓ Copied' : '🤖 Ask AI'}
                </button>
              ) : (
                <span style={{
                  padding: '5px 12px',
                  fontSize: '0.75rem',
                  color: '#6b7280',
                  fontWeight: 500,
                  whiteSpace: 'nowrap' as const,
                  background: '#f9fafb',
                  borderRadius: '6px',
                  border: '1px solid #e5e7eb',
                }}>
                  {issue.fix ? issue.fix.slice(0, 40) + (issue.fix.length > 40 ? '…' : '') : 'See details below'}
                </span>
              )}
            </div>
          )
        })}
      </div>

      {/* Footer hint */}
      {failures.length > 3 && (
        <p style={{ margin: '10px 0 0', fontSize: '0.78rem', color: '#a16207' }}>
          +{failures.length - 3} more issue{failures.length - 3 !== 1 ? 's' : ''} in the table below.
        </p>
      )}
    </div>
  )
}