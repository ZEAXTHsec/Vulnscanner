'use client'

import { useState } from 'react'
import { useScan } from '@/hooks/useScan'
import SummaryCards from './SummaryCards'
import TechBadges from './TechBadges'
import ResultsTable from './ResultsTable'
import TopIssues from './TopIssues'
import FixAllBanner from './FixAllBanner'
import TrustSignals from './TrustSignals'

export default function ScanInput() {
  const [url, setUrl] = useState('')
  const { scan, isLoading, report, error } = useScan()

  const handleScan = () => {
    if (url.trim()) scan(url)
  }

  return (
    <div style={{ color: '#111' }}>

      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: 0 }}>🔍 Fix your website security in minutes</h1>
        <p style={{ color: '#666', marginTop: '4px' }}>
          Paste a URL. Get a prioritized list of issues with copy-paste fixes.
        </p>
      </div>

      {/* Input */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '1.5rem' }}>
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleScan()}
          placeholder="example.com"
          style={{
            flex: 1, padding: '10px 14px', fontSize: '1rem',
            border: '1px solid #d1d5db', borderRadius: '8px', outline: 'none',
          }}
        />
        <button
          onClick={handleScan}
          disabled={isLoading}
          style={{
            padding: '10px 24px', fontSize: '1rem', fontWeight: 600,
            background: isLoading ? '#9ca3af' : '#1d4ed8', color: 'white',
            border: 'none', borderRadius: '8px', cursor: isLoading ? 'not-allowed' : 'pointer',
          }}
        >
          {isLoading ? '⏳ Analyzing...' : 'Analyze my site'}
        </button>
      </div>

      {/* Error */}
      {error && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fca5a5', color: '#dc2626',
          padding: '12px 16px', borderRadius: '8px', marginBottom: '1rem',
        }}>
          ⚠️ {error}
        </div>
      )}

      {/* Report */}
      {report && (
        <div>
          <SummaryCards
            summary={report.summary}
            url={report.url}
            timestamp={report.timestamp}
          />
          <TechBadges results={report.results} />
          <FixAllBanner results={report.results} summary={report.summary} url={report.url} />
          <TopIssues results={report.results} summary={report.summary} />
          <ResultsTable results={report.results} url={report.url} timestamp={report.timestamp} />
          <TrustSignals results={report.results} summary={report.summary} />
        </div>
      )}

    </div>
  )
}