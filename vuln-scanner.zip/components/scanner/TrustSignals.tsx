'use client'

// components/scanner/TrustSignals.tsx
// Reassurance block shown at the bottom of every scan report.
// Tells the user what was checked and found safe — counterbalances the list of issues.

import { ScanResult, ScanSummary } from '@/lib/types'

interface Props {
  results: ScanResult[]
  summary: ScanSummary
}

export default function TrustSignals({ results, summary }: Props) {
  const noSecrets = results.some((r) => r.checkId === 'secrets-ok')
  const hasHttps  = results.some((r) => r.checkId === 'https-ok')
  const noXss     = results.some((r) => r.checkId === 'injection-xss-ok' || r.checkId === 'xss-dom-ok')
  const noExposed = results.some((r) => r.checkId === 'exposed-files-ok')
  const noTakeover = results.some((r) => r.checkId === 'takeover-ok')

  const signals: string[] = []
  if (hasHttps)    signals.push('All traffic encrypted over HTTPS')
  if (noSecrets)   signals.push('No API keys or secrets exposed in source')
  if (noXss)       signals.push('No XSS injection patterns detected')
  if (noExposed)   signals.push('No sensitive files publicly accessible')
  if (noTakeover)  signals.push('No subdomain takeover vulnerabilities')
  if (summary.high === 0) signals.push('No critical vulnerabilities found')

  if (signals.length === 0) return null

  return (
    <div style={{
      background: '#f0fdf4',
      border: '1px solid #bbf7d0',
      borderRadius: '12px',
      padding: '16px 20px',
      marginTop: '1.5rem',
    }}>
      <div style={{ fontWeight: 700, fontSize: '0.85rem', color: '#15803d', marginBottom: '10px' }}>
        ✅ What looks good
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
        {signals.map((s) => (
          <div key={s} style={{ fontSize: '0.82rem', color: '#166534', display: 'flex', alignItems: 'center', gap: '7px' }}>
            <span style={{ color: '#16a34a', fontWeight: 700 }}>✓</span>
            {s}
          </div>
        ))}
      </div>
      {summary.high === 0 && summary.medium <= 2 && (
        <div style={{
          marginTop: '12px',
          paddingTop: '12px',
          borderTop: '1px solid #bbf7d0',
          fontSize: '0.8rem',
          color: '#15803d',
          fontWeight: 600,
        }}>
          ✔ Safe to deploy after fixing the issues above
        </div>
      )}
    </div>
  )
}