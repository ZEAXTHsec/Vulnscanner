'use client'

// components/scanner/FixAllBanner.tsx
// The conversion-driving block. Sits at the very top of the report.
// Generates a single combined AI prompt covering every unfixed issue so the
// user can paste once into ChatGPT / Claude and get everything fixed together.

import { useState } from 'react'
import { ScanResult, ScanSummary } from '@/lib/types'

interface Props {
  results: ScanResult[]
  summary: ScanSummary
  url: string
}

function scoreColor(score: number): string {
  if (score >= 80) return '#16a34a'
  if (score >= 50) return '#d97706'
  return '#dc2626'
}

export default function FixAllBanner({ results, summary, url }: Props) {
  const [copied, setCopied] = useState(false)

  const fixable = results.filter((r) => r.status === 'fail' && r.fixPrompt)
  const totalGain = results
    .filter((r) => r.status === 'fail')
    .reduce((sum, r) => {
      const w: Record<string, number> = { high: 12, medium: 6, low: 2, info: 0 }
      return sum + (w[r.severity] ?? 0)
    }, 0)
  const projectedScore = Math.min(100, summary.score + totalGain)

  // Nothing to fix with AI prompts
  if (fixable.length === 0) return null

  const combinedPrompt = [
    `I scanned ${url} for security issues and found ${results.filter(r => r.status === 'fail').length} problems. Please help me fix all of them. My current security score is ${summary.score}/100.\n`,
    ...fixable.map((r, i) => `--- Issue ${i + 1}: ${r.name} (${r.severity.toUpperCase()}) ---\n${r.fixPrompt}`)
  ].join('\n\n')

  const handleCopy = () => {
    navigator.clipboard.writeText(combinedPrompt).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    })
  }

  return (
    <div style={{
      background: 'linear-gradient(135deg, #1e1b4b 0%, #1d4ed8 100%)',
      borderRadius: '14px',
      padding: '20px 24px',
      marginBottom: '1.5rem',
      color: 'white',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
        {/* Left: heading + subtitle */}
        <div>
          <div style={{ fontWeight: 700, fontSize: '1.05rem', marginBottom: '4px' }}>
            🚀 Fix everything in one go
          </div>
          <div style={{ fontSize: '0.83rem', color: '#c7d2fe', lineHeight: 1.5 }}>
            {fixable.length} issue{fixable.length !== 1 ? 's' : ''} with AI fixes ready
            {totalGain > 0 && (
              <span style={{ marginLeft: '8px', color: '#6ee7b7', fontWeight: 600 }}>
                — score: <span style={{ textDecoration: 'line-through', opacity: 0.7 }}>{summary.score}</span>
                {' → '}
                <span style={{ color: '#6ee7b7' }}>{projectedScore}</span>
              </span>
            )}
          </div>
        </div>

        {/* Right: copy button */}
        <button
          onClick={handleCopy}
          style={{
            padding: '10px 22px',
            fontSize: '0.88rem',
            fontWeight: 700,
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            background: copied ? '#16a34a' : 'white',
            color: copied ? 'white' : '#1d4ed8',
            transition: 'all 0.2s',
            whiteSpace: 'nowrap' as const,
            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
          }}
        >
          {copied ? '✓ Copied! Paste into AI' : '📋 Copy Full Fix Prompt'}
        </button>
      </div>

      {/* Issue preview pills */}
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '14px' }}>
        {fixable.slice(0, 5).map((r) => (
          <span
            key={r.checkId}
            style={{
              background: 'rgba(255,255,255,0.12)',
              borderRadius: '999px',
              padding: '2px 10px',
              fontSize: '0.72rem',
              color: '#e0e7ff',
              fontWeight: 500,
            }}
          >
            {r.name}
          </span>
        ))}
        {fixable.length > 5 && (
          <span style={{
            background: 'rgba(255,255,255,0.08)',
            borderRadius: '999px',
            padding: '2px 10px',
            fontSize: '0.72rem',
            color: '#a5b4fc',
            fontWeight: 500,
          }}>
            +{fixable.length - 5} more
          </span>
        )}
      </div>
    </div>
  )
}