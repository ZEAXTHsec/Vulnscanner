'use client'

// components/scanner/ResultsTable.tsx
// Renders the scan results table. Accepts the results array from a ScanReport
// and handles filtering by severity/status, expand-on-click for long fix text,
// and a "show all / show failures only" toggle.

'use client'

import { useState } from 'react'
import { ScanResult } from '@/lib/types'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Props {
  results: ScanResult[]
  url?: string
  timestamp?: string
}

type Filter = 'all' | 'fail' | 'high' | 'medium' | 'low'

// ─── Helpers ──────────────────────────────────────────────────────────────────

const SEVERITY_COLOR: Record<string, string> = {
  high: '#ef4444',
  medium: '#f97316',
  low: '#eab308',
  info: '#6b7280',
}

function statusIcon(status: string): string {
  if (status === 'pass') return '✅'
  if (status === 'skip') return '⏭️'
  return '❌'
}

function severityBadge(severity: string) {
  const color = SEVERITY_COLOR[severity] ?? '#6b7280'
  return (
    <span
      style={{
        color,
        background: color + '18',
        padding: '3px 10px',
        borderRadius: '999px',
        fontSize: '0.72rem',
        fontWeight: 700,
        textTransform: 'uppercase' as const,
        letterSpacing: '0.05em',
        whiteSpace: 'nowrap' as const,
      }}
    >
      {severity}
    </span>
  )
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function ResultsTable({ results, url, timestamp }: Props) {
  const [filter, setFilter] = useState<Filter>('all')
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const [copied, setCopied] = useState<string | null>(null)

  const toggleExpand = (checkId: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(checkId)) next.delete(checkId)
      else next.add(checkId)
      return next
    })
  }

  const handleCopyPrompt = (checkId: string, prompt: string) => {
    navigator.clipboard.writeText(prompt).then(() => {
      setCopied(checkId)
      setTimeout(() => setCopied(null), 2000)
    })
  }

  const handleDownload = () => {
    const report = {
      url: url ?? '',
      scannedAt: timestamp ?? new Date().toISOString(),
      results,
    }
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
    const href = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    const safeName = (url ?? 'scan').replace(/https?:\/\//, '').replace(/[^a-z0-9]/gi, '-')
    a.download = `scan-${safeName}-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(href)
  }

  const filtered = results.filter((r) => {
    if (filter === 'all') return true
    if (filter === 'fail') return r.status === 'fail'
    return r.severity === filter && r.status === 'fail'
  })

  const failCount = results.filter((r) => r.status === 'fail').length

  const FILTERS: { key: Filter; label: string }[] = [
    { key: 'all', label: `All (${results.length})` },
    { key: 'fail', label: `Failures (${failCount})` },
    { key: 'high', label: 'High' },
    { key: 'medium', label: 'Medium' },
    { key: 'low', label: 'Low' },
  ]

  return (
    <div>
      {/* Filter pills + download button */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
        {FILTERS.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            style={{
              padding: '5px 14px',
              fontSize: '0.8rem',
              fontWeight: 600,
              border: '1px solid',
              borderColor: filter === key ? '#1d4ed8' : '#d1d5db',
              borderRadius: '999px',
              background: filter === key ? '#1d4ed8' : 'white',
              color: filter === key ? 'white' : '#374151',
              cursor: 'pointer',
            }}
          >
            {label}
          </button>
        ))}
        {/* Spacer pushes download to the right */}
        <div style={{ flex: 1 }} />
        <button
          onClick={handleDownload}
          title="Download full scan report as JSON"
          style={{
            padding: '5px 14px',
            fontSize: '0.8rem',
            fontWeight: 600,
            border: '1px solid #d1d5db',
            borderRadius: '999px',
            background: 'white',
            color: '#374151',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '5px',
          }}
        >
          ⬇ Download Report
        </button>
      </div>

      {filtered.length === 0 ? (
        <div style={{ padding: '2rem', textAlign: 'center', color: '#9ca3af', fontSize: '0.9rem' }}>
          No results match this filter.
        </div>
      ) : (
        <div style={{ border: '1px solid #e5e7eb', borderRadius: '10px', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.88rem' }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
                {['', 'Check', 'Severity', 'Detail', 'Fix', ''].map((h, i) => (
                  <th
                    key={i}
                    style={{
                      padding: '11px 16px',
                      textAlign: 'left',
                      fontWeight: 600,
                      color: '#374151',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => {
                const isExpanded = expanded.has(r.checkId)
                const longFix = r.fix && r.fix.length > 80

                return (
                  <tr
                    key={r.checkId + i}
                    style={{
                      borderBottom: '1px solid #f3f4f6',
                      background: i % 2 === 0 ? 'white' : '#fafafa',
                      verticalAlign: 'top',
                    }}
                  >
                    {/* Status icon */}
                    <td style={{ padding: '12px 16px', fontSize: '1rem', whiteSpace: 'nowrap' }}>
                      {statusIcon(r.status)}
                    </td>

                    {/* Check name */}
                    <td style={{ padding: '12px 16px', fontWeight: 600, whiteSpace: 'nowrap', color: '#111' }}>
                      {r.name}
                    </td>

                    {/* Severity badge */}
                    <td style={{ padding: '12px 16px' }}>
                      {severityBadge(r.severity)}
                    </td>

                    {/* Detail */}
                    <td style={{ padding: '12px 16px', color: '#4b5563', maxWidth: '320px', lineHeight: '1.5' }}>
                      {r.detail}
                    </td>

                    {/* Fix — expandable if long */}
                    <td style={{ padding: '12px 16px', color: '#2563eb', fontSize: '0.82rem', maxWidth: '240px', lineHeight: '1.5' }}>
                      {r.fix ? (
                        longFix ? (
                          <span>
                            {isExpanded ? r.fix : r.fix.slice(0, 80) + '…'}
                            {' '}
                            <button
                              onClick={() => toggleExpand(r.checkId)}
                              style={{
                                background: 'none',
                                border: 'none',
                                color: '#1d4ed8',
                                cursor: 'pointer',
                                fontSize: '0.78rem',
                                padding: 0,
                                fontWeight: 600,
                              }}
                            >
                              {isExpanded ? 'less' : 'more'}
                            </button>
                          </span>
                        ) : (
                          r.fix
                        )
                      ) : (
                        <span style={{ color: '#9ca3af' }}>—</span>
                      )}
                    </td>

                    {/* Copy for AI — only shown on fail rows with a fixPrompt */}
                    <td style={{ padding: '12px 16px', whiteSpace: 'nowrap' }}>
                      {r.fixPrompt && r.status === 'fail' ? (
                        <button
                          onClick={() => handleCopyPrompt(r.checkId, r.fixPrompt!)}
                          title="Copy an AI-ready prompt for this fix"
                          style={{
                            padding: '4px 10px',
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            border: '1px solid',
                            borderColor: copied === r.checkId ? '#16a34a' : '#d1d5db',
                            borderRadius: '6px',
                            background: copied === r.checkId ? '#f0fdf4' : 'white',
                            color: copied === r.checkId ? '#16a34a' : '#6b7280',
                            cursor: 'pointer',
                            transition: 'all 0.15s',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                          }}
                        >
                          {copied === r.checkId ? '✓ Copied' : '🤖 Ask AI'}
                        </button>
                      ) : null}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}