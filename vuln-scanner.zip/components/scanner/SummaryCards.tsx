'use client'

// components/scanner/SummaryCards.tsx
// Renders the row of summary cards (Security Score, High, Medium, Low, Passed, Skipped)
// and the scanned-URL / timestamp line beneath them.
// Replace the inline "Summary Cards" block in ScanInput.tsx with:
//   <SummaryCards summary={report.summary} url={report.url} timestamp={report.timestamp} />

import { ScanSummary } from '@/lib/types'

interface Props {
  summary: ScanSummary
  url: string
  timestamp: string
}

interface CardDef {
  label: string
  value: number
  unit?: string
  bg: string
  color: string
}

function scoreColor(score: number): string {
  if (score >= 80) return '#22c55e'
  if (score >= 50) return '#f97316'
  return '#ef4444'
}

function scoreLabel(score: number): string {
  if (score >= 80) return 'Good'
  if (score >= 50) return 'Fair'
  return 'Poor'
}

export default function SummaryCards({ summary, url, timestamp }: Props) {
  const cards: CardDef[] = [
    {
      label: 'Security Score',
      value: summary.score,
      unit: '/ 100',
      bg: '#111',
      color: scoreColor(summary.score),
    },
    { label: 'High',    value: summary.high,    bg: '#fef2f2', color: '#ef4444' },
    { label: 'Medium',  value: summary.medium,  bg: '#fff7ed', color: '#f97316' },
    { label: 'Low',     value: summary.low,     bg: '#fefce8', color: '#eab308' },
    { label: 'Passed',  value: summary.passed,  bg: '#f0fdf4', color: '#22c55e' },
    { label: 'Info',    value: summary.info,    bg: '#f0f9ff', color: '#0ea5e9' },
    { label: 'Skipped', value: summary.skipped, bg: '#f9fafb', color: '#6b7280' },
  ]

  return (
    <div style={{ marginBottom: '1.5rem' }}>
      {/* Cards row */}
      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '12px' }}>
        {cards.map((card) => (
          <div
            key={card.label}
            style={{
              background: card.bg,
              padding: '14px 20px',
              borderRadius: '10px',
              minWidth: '90px',
              textAlign: 'center',
              position: 'relative',
            }}
          >
            <div style={{ fontSize: '1.8rem', fontWeight: 700, color: card.color, lineHeight: 1 }}>
              {card.value}
            </div>
            <div
              style={{
                fontSize: '0.72rem',
                color: card.bg === '#111' ? '#aaa' : '#555',
                marginTop: '4px',
              }}
            >
              {card.label}
              {card.unit && (
                <span style={{ marginLeft: '3px', opacity: 0.7 }}>{card.unit}</span>
              )}
            </div>
            {/* Score label badge on the score card */}
            {card.label === 'Security Score' && (
              <div
                style={{
                  marginTop: '6px',
                  fontSize: '0.68rem',
                  fontWeight: 700,
                  color: scoreColor(summary.score),
                  background: scoreColor(summary.score) + '22',
                  borderRadius: '999px',
                  padding: '1px 8px',
                  display: 'inline-block',
                  letterSpacing: '0.04em',
                }}
              >
                {scoreLabel(summary.score)}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Scan meta line */}
      <p style={{ color: '#888', fontSize: '0.84rem', margin: 0 }}>
        📡 Scanned:{' '}
        <strong style={{ color: '#374151' }}>{url}</strong>
        {' — '}
        {new Date(timestamp).toLocaleString()}
      </p>
    </div>
  )
}