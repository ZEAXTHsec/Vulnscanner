// app/page.tsx

import ScanInput from '@/components/scanner/ScanInput'
import ScanHistory from '@/components/scanner/ScanHistory'

export default function Home() {
  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
      <ScanInput />
      <ScanHistory />
    </div>
  )
}